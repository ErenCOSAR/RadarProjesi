import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
import random
import numpy as num
import scipy.fft as fft
from scipy.signal import spectrogram
from sklearn.ensemble import RandomForestClassifier

#örneklem frekansı
fs = 1000
t = num.linspace(0, 1, fs)

ucak_sekli = [[0, 0.8],[0.2, 0.2],[0.7, -0.4],[0.2, -0.2], [0, -0.6],[-0.2, -0.2],[-0.7, -0.4],[-0.2, 0.2]] #nokta görünümü yerine uçak şeklinde olması adına kullnadım

hedefler = []
def hedef_uret():
    return {
        "x": random.uniform(-8, 8),
        "y": random.uniform(-8, 8),
        "vx": random.uniform(-0.2, 0.2),
        "vy": random.uniform(-0.2, 0.2),
        "dost": random.randint(0, 1),
        "aci": random.uniform(0, 3)
    }

for _ in range(6):
    hedefler.append(hedef_uret())

X, y = [], []
for _ in range(2000):
    mesafe = num.random.uniform(0, 10)
    hiz = num.random.uniform(0, 0.3)
    doppler = num.random.uniform(-1, 1)

    # daha dengeli etiketleme
    if mesafe < 3 and abs(doppler) > 0.3:
        etiket = 1
    elif mesafe < 6 and abs(doppler) > 0.6:
        etiket = 1
    else:
        etiket = 0

    # gürültü ekleyerek denge sağlıyoruz
    if num.random.rand() < 0.15:
        etiket = 1 - etiket

    X.append([mesafe, hiz, doppler])
    y.append(etiket)

model = RandomForestClassifier(n_estimators = 60)
model.fit(X, y)

# özellik çıkarma kısmı
def ozellik_cikar(h):
    mesafe = num.sqrt(h["x"] ** 2 + h["y"] ** 2)
    hiz = num.sqrt(h["vx"] ** 2 + h["vy"] ** 2)
    doppler = (h["x"] * h["vx"] + h["y"] * h["vy"]) / (mesafe + 1e-6)

    return num.array([mesafe, hiz, doppler]).reshape(1, -1), mesafe, doppler


def radar_sinyali():
    sinyal = num.zeros(len(t))

    for h in hedefler:
        mesafe = num.sqrt(h["x"] ** 2 + h["y"] ** 2)
        frekans = 5 + ((h["x"] * h["vx"] + h["y"] * h["vy"]) / (mesafe + 1e-6)) * 10
        sinyal += num.sin(2 * num.pi * frekans * t) / (mesafe + 1)
    sinyal += num.random.normal(0, 0.4, len(t))

    return sinyal

# tuval kodları
fig = plt.figure(figsize = (12, 6))
ax_radar = plt.subplot(1, 2, 1)
ax_fft = plt.subplot(2, 2, 2)
ax_spec = plt.subplot(2, 2, 4)
ax_radar.set_facecolor("black")
ax_radar.set_xlim(-10, 10)
ax_radar.set_ylim(-10, 10)

for r in [2, 4, 6, 8, 10]:
    ax_radar.add_patch(plt.Circle((0, 0), r, fill = False, color = 'lime', alpha = 0.4))# radar çizgisi kodları
ax_radar.add_patch(plt.Circle((0, 0), 2.5, color = 'red', fill = False, linestyle = '--')) # tehlikeli alan kodları

cizgi, = ax_radar.plot([], [], color = 'lime')


ucaklar = []
etiketler = []
def baslat():
    global ucaklar, etiketler

    for ucak in ucaklar:
        ucak.remove()
    for etiket in etiketler:
        etiket.remove()

    ucaklar.clear()
    etiketler.clear()

    for _ in hedefler:
        ucak = patches.Polygon(ucak_sekli, color = 'gray')
        ax_radar.add_patch(ucak)
        ucaklar.append(ucak)

        etiket = ax_radar.annotate("", xy = (0, 0), xytext = (8, 8),textcoords = "offset points", fontsize = 7, color = "white", bbox = dict(boxstyle = "round", fc = "black", alpha = 0.5))
        etiketler.append(etiket)

baslat()

def hedef_guncelle():
    for h in hedefler:
        h["x"] += h["vx"]
        h["y"] += h["vy"]

    hedefler[:] = [h for h in hedefler if abs(h["x"]) < 12 and abs(h["y"]) < 12]

    if len(hedefler) < 8 and random.random() < 0.3:
        hedefler.append(hedef_uret())


def guncelle(derece):
    hedef_guncelle()

    if len(ucaklar) != len(hedefler):
        baslat()

    sinyal = radar_sinyali()

    fft_veri = num.abs(fft.fft(sinyal))

    ax_fft.clear()
    ax_fft.plot(fft_veri, color="cyan")
    ax_fft.set_title("FFT Spektrumu")

    ax_spec.clear()
    f, tt, Sxx = spectrogram(sinyal, fs = fs)
    ax_spec.pcolormesh(tt, f, Sxx, shading = 'gouraud')
    ax_spec.set_title("Spektrogram")

    aci = num.radians(derece)
    cizgi.set_data([0, 10 * num.cos(aci)], [0, 10 * num.sin(aci)])

    for i, h in enumerate(hedefler):
        features, mesafe, doppler = ozellik_cikar(h)
        olasilik = model.predict_proba(features)[0][1]
        aci_ucak = num.arctan2(h["vy"], h["vx"]) - num.pi / 2
        c, s = num.cos(aci_ucak), num.sin(aci_ucak)

        sekil = [[p[0] * c - p[1] * s + h["x"], p[0] * s + p[1] * c + h["y"]] for p in ucak_sekli]

        if mesafe < 2.5:
            renk = "white"
        else:
            if h["dost"]:
                if olasilik < 0.3:
                    renk = "green"
                elif olasilik < 0.6:
                    renk = "blue"
                else:
                    renk = "hotpink"
            else:
                if olasilik < 0.3:
                    renk = "hotpink"
                elif olasilik < 0.6:
                    renk = "red"
                else:
                    renk = "red"

        ucaklar[i].set_xy(sekil)
        ucaklar[i].set_facecolor(renk)
        etiketler[i].xy = (h["x"], h["y"])
        etiketler[i].set_text(f"{'DOST' if h['dost'] else 'DÜŞMAN'}\n X:{h['x']:.1f} Y:{h['y']:.1f}")

    return [cizgi] + ucaklar + etiketler

#çalıştırma alanı
animasyon = FuncAnimation(fig, guncelle, frames = 360, interval = 50, blit = False)
plt.tight_layout()
ax_radar.set_aspect('equal')
plt.show()
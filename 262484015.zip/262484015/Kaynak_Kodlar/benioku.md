# Yapay Zeka Destekli Radar Sistemi

## Proje Amacı
Bu proje radar sistemlerinin temel çalışma mantığını simüle etmek amacıyla geliştirilmiştir.

Sistem;
- Radar sinyali üretimi
- FFT (Fast Fourier Transform) analizi
- Spektrogram oluşturma
- Doppler etkisi hesaplama
- Dost / Düşman tanıma (IFF)
- Yapay zeka destekli tehdit değerlendirmesi
- Gerçek zamanlı radar ekranı
özelliklerini içermektedir.

## Kullanılan Teknolojiler

- Python
- NumPy
- Matplotlib
- SciPy
- Scikit-Learn 
- Pandas
- Seaborn
- Tensorflow

## Proje Dosyaları

RADARPROJESI/
│
├── frekans.py
├── iffRadarSistemi.py
├── mainDoppler.py
├── radarEkrani.py
├── fullFinalRadar.py
├── main.py
└── benioku.md

## Sistem Özellikleri:

### FFT Analizi
Radar sinyalinin frekans bileşenleri FFT kullanılarak analiz edilir.

### Doppler Analizi
Hedeflerin radara göre yaklaşma ve uzaklaşma durumları Doppler etkisi ile belirlenir.

### IFF Sistemi
Hedefler dost veya düşman olarak sınıflandırılır.

### Yapay Zeka Modülü
Mesafe, hız ve Doppler bilgileri kullanılarak hedeflerin tehdit seviyeleri değerlendirilir.

### Radar Görselleştirmesi
Gerçek zamanlı radar ekranı üzerinde hareket eden hedefler gösterilir.

## Kurulum
Gerekli paketler:

```bash
pip install numpy pandas matplotlib scipy scikit-learn seaborn tensorflow
```

## Çalıştırma
```bash
python fullFinalRadar.py
```

## Not
Bu proje eğitim ve simülasyon amaçlı geliştirilmiştir. Gerçek radar sistemlerinin sadeleştirilmiş bir modelidir.
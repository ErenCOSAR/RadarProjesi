import matplotlib.pyplot as plot  # Matplotlib'in MATLAB gibi çalışmasını sağlayan fonksiyonlar koleksiyonudur
import matplotlib.patches as patches # Matplotlib içerisindeki geometrik şekiller oluşturmak ve bunları grafiklere eklemek için kullandığım araç seti.
import numpy as num # büyük, çok boyutlu diziler ve matrisler üzerinde hızlı matematiksel ve istatistiksel işlemler yapmayı sağlamak için kullanılacak
from matplotlib.animation import FuncAnimation # Matplotlib kütüphanesinde hareketli grafikler oluşturmak için kullandım.

# 1. kısım : Tuval oluşturduğum yer
fig, gAlani = plot.subplots(figsize = (8, 8)) # radar ekranının özellikleri → tuvalin boyutları, rengi, x-y koordinatları
gAlani.set_facecolor('black')
gAlani.set_xlim(-10, 10)
gAlani.set_ylim(-10, 10)

# Radar Halkalarını oluşturdum
for r in [2, 4, 6, 8, 10]:
    gAlani.add_patch(plot.Circle((0, 0), r, color = 'lime', fill = False, alpha = 0.5)) #standart radar halkaları
gAlani.add_patch(plot.Circle((0, 0), 2.5, color = 'red', fill = False, linestyle = '--')) #tehlike alanı

# 2. Uçak Şekli (Delta Kanat)
ucak_sekli = [[0, 0.8],[0.2, 0.2],[0.7, -0.4],[0.2, -0.2], [0, -0.6],[-0.2, -0.2],[-0.7, -0.4],[-0.2, 0.2]] #nokta görünümü yerine uçak şeklinde olması adına kullnadım

# Hedef Verileri
hedefler = [
    {'x': 4, 'y': 6, 'vx': -0.15, 'vy': -0.16, 'dost': False, 'acisi': 0.0}, #uçak 1
    {'x': 0, 'y': -8, 'vx': 0.05, 'vy': 0.2, 'dost': False, 'acisi': 1.5},   #uçak 2
    {'x': -5, 'y': 2, 'vx': 0.1, 'vy': -0.05, 'dost': True, 'acisi': 3.0},   #uçak 3
    {'x': -2, 'y': -3, 'vx': -0.09, 'vy': 0.4, 'dost': True, 'acisi': 2.5}   #uçak 4
]

gorsel_nesneler = []
for h in hedefler:
    ucak_patch = patches.Polygon(ucak_sekli, closed = True, color = 'gray')
    gAlani.add_patch(ucak_patch)
    #  boxstyle ile kutu içine aldım, xytext ile hafifçe uçağın yanına kaydırdım bu sayede koordinatları görebileceğim
    etiket = gAlani.annotate("", xy = (0, 0), xytext = (15, 15), textcoords = 'offset points', fontsize = 6, color='white', bbox=dict(boxstyle = "round", fc= "black", alpha = 0.6))
    gorsel_nesneler.append({'patch': ucak_patch, 'etiket': etiket})

cizgi, = gAlani.plot([], [], color = 'lime', linewidth = 2)

# 3. Güncelleme Fonksiyonu
def guncelle(derece):
    radyan = num.radians(derece)
    cizgi.set_data([0, 10 * num.cos(radyan)], [0, 10 * num.sin(radyan)])
    
    cizimler = [cizgi]
    for i, h in enumerate(hedefler):
        # uçakların manevra kabiliyeti için yazılan kodlar
        h['acisi'] += 0.05
        h['vx'] += num.cos(h['acisi']) * 0.005
        h['vy'] += num.sin(h['acisi']) * 0.005
        h['vx'], h['vy'] = num.clip(h['vx'], -0.25, 0.25), num.clip(h['vy'], -0.25, 0.25)
        h['x'] += h['vx']; h['y'] += h['vy']

        # Sınır dışıysa rastgele konumda yeniden başlatılacak çünkü sonsuza kadar radar içerisinde uçakların kalmasını istiyorum
        if abs(h['x']) > 10 or abs(h['y']) > 10:
            h['x'] = num.random.uniform(-9, 9)
            h['y'] = num.random.uniform(-9, 9)
            h['vx'] = num.random.uniform(-0.1, 0.1)
            h['vy'] = num.random.uniform(-0.1, 0.1)

        # doppler ve renkler bölümü
        mesafe = num.sqrt(h['x'] ** 2 + h['y'] ** 2)
        doppler = (h['x'] * h['vx'] + h['y'] * h['vy']) / (mesafe + 0.001)
        renk = ('green' if doppler < 0 else 'blue') if h['dost'] else ('red' if doppler < 0 else 'hotpink')
        if mesafe < 2.5: 
            renk = 'white'
            
        # uçakların gittiği yöne doğru şekillerinin de gerçekçi olması için yaptım ( aksi takdirde uçak stabil kalıyor)
        aci = num.arctan2(h['vy'], h['vx']) - num.pi / 2
        cos_a, sin_a = num.cos(aci), num.sin(aci)
        yeni_coords = [[ p[0] * cos_a - p[1] * sin_a + h['x'], p[0] * sin_a + p[1] * cos_a + h['y']] for p in ucak_sekli]
        
        # görsel güncellemeler
        nesne = gorsel_nesneler[i]
        nesne['patch'].set_xy(yeni_coords)
        nesne['patch'].set_facecolor(renk)
        # Etiket Güncelleme (DOST/DÜŞMAN sağ üstte, Koordinatlar sol altta)
        nesne['etiket'].xy = (h['x'], h['y'])
        durum = "DOST" if h['dost'] else "DÜŞMAN"
        # \n ile alt satıra geçiş, koordinatlar için sol alt hizalama
        nesne['etiket'].set_text(f"{durum}\n  X:{h['x']:.1f} Y:{h['y']:.1f}")
        nesne['etiket'].set_color(renk)
        
        cizimler.extend([nesne['patch'], nesne['etiket']])
    return cizimler

# çalıştırma kısmı
anim = FuncAnimation(fig, guncelle, frames=range(0, 360, 2), interval = 50, blit = False)
gAlani.set_aspect('equal')
plot.show()
import numpy as num  # büyük, çok boyutlu diziler ve matrisler üzerinde hızlı matematiksel ve istatistiksel işlemler yapmayı sağlamak için kullanılacak
import matplotlib.pyplot as plt # Matplotlib'in MATLAB gibi çalışmasını sağlayan fonksiyonlar koleksiyonudur
import matplotlib.patches as patches # Matplotlib içerisindeki geometrik şekiller oluşturmak ve bunları grafiklere eklemek için kullandığım araç seti.
from matplotlib.animation import FuncAnimation # Matplotlib kütüphanesinde hareketli grafikler oluşturmak için kullandım.
import scipy.fft as fft #Hızlı Fourier Dönüşümünü projede kullanabilmek için

from sklearn.model_selection import train_test_split #veri setinmi eğitim ve test olmak üzere iki parçaya bölmek adına kullanıyorum.
from sklearn.ensemble import RandomForestClassifier  #tek bir ağaç yerine yüzlerce ağaç oluşturmak ve her ağacın tahminini oylayarak en doğru sonucu bulmaya çalışmak için kullandım
from sklearn.metrics import accuracy_score, confusion_matrix #modelin ne kadar başarılı olduğunu anlamayı sağlayan değerlendirme araçları.

import seaborn as sns #Matplotlib tabanlı, çok daha şık ve gelişmiş istatistiksel grafikler çizmemize yarayan kütüphanedir
import pandas as pd # Verileri satır-sütun (Excel tablosu gibi) yapısına sokarak görselleştirmeyi kolaylaştırmak için kullanılacak.


orneklemFrekansı = 1000
zaman = num.linspace(0, 1, orneklemFrekansı)

#uçaklar
hedefler = [
    {'x': 4, 'y': 6, 'vx': -0.15, 'vy': -0.16, 'dost': 0, 'acisi': 0.0},
    {'x': 0, 'y': -8, 'vx': 0.05, 'vy': 0.2, 'dost': 0, 'acisi': 1.5},
    {'x': -5, 'y': 2, 'vx': 0.1, 'vy': -0.05, 'dost': 1, 'acisi': 3.0},
    {'x': -2, 'y': -3, 'vx': -0.09, 'vy': 0.4, 'dost': 1, 'acisi': 2.5}
]

#sinyal üretme aşaması
def radar_sinyal_uret(hedefler, zaman):
    sinyal = num.zeros(len(zaman))

    for h in hedefler:
        mesafe = num.sqrt(h['x'] ** 2 + h['y'] ** 2)
        echo = num.sin(2 * num.pi * 5 * zaman) * (1 / (mesafe + 1))
        sinyal += echo
    sinyal += num.random.normal(0, 0.7, len(zaman))
    return sinyal

#radar ekranının özellikleri
fig, ax = plt.subplots(figsize=(8, 8))
ax.set_facecolor("black")
ax.set_xlim(-10, 10)
ax.set_ylim(-10, 10)
ax.set_aspect('equal')

#radar halkaları
for r in [2, 4, 6, 8, 10]:
    ax.add_patch(plt.Circle((0, 0), r, color = 'lime', fill = False, alpha = 0.5)) # normal radar halkaları
ax.add_patch(plt.Circle((0, 0), 2.5, color = 'red', fill = False, linestyle = '--')) # tehlike bölgesi halkası

cizgi, = ax.plot([], [], color = 'lime', lw = 2)

ucak_sekli = [[0,0.8],[0.2,0.2],[0.7,-0.4],[0.2,-0.2], [0,-0.6],[-0.2,-0.2],[-0.7,-0.4],[-0.2,0.2]] # nokta yerine uçak şeklini verir

gorsel_nesneler = []
for h in hedefler:
    patch = patches.Polygon(ucak_sekli, closed = True, color = 'gray')
    ax.add_patch(patch)

    #Koordinatların ekranda görünmesini sağlayan kısım
    etiket = ax.annotate("", xy = (0, 0), xytext = (10, 10), textcoords = 'offset points', fontsize = 7, color = 'white', bbox = dict(boxstyle = "round", fc = "black", alpha = 0.6))
    gorsel_nesneler.append({"patch": patch, "etiket": etiket})


veriler = []
etiketler = []
def guncelle(derece):
    global veriler, etiketler

    # radar sinyali üretme
    radarSinyali = radar_sinyal_uret(hedefler, zaman)

    # FFT kodları
    fftSinyali = fft.fft(radarSinyali)
    buyukluk = num.abs(fftSinyali)

    # ML dataset oluşurma kısmı
    ozellikler = [num.max(buyukluk), num.mean(buyukluk), num.std(buyukluk)]

    # label : güçlü sinyal varsa hedef var
    label = 1 if num.max(buyukluk) > 50 else 0

    veriler.append(ozellikler)
    etiketler.append(label)

    # hedef hareketleri
    for i, h in enumerate(hedefler):
        h['acisi'] += 0.05
        h['vx'] += num.cos(h['acisi']) * 0.005
        h['vy'] += num.sin(h['acisi']) * 0.005
        h['vx'] = num.clip(h['vx'], -0.25, 0.25)
        h['vy'] = num.clip(h['vy'], -0.25, 0.25)
        h['x'] += h['vx']
        h['y'] += h['vy']

        mesafe = num.sqrt(h['x'] ** 2 + h['y'] ** 2)

        # renk
        renk = 'yellow' if h['dost'] == 0 else 'purple'

        aci = num.arctan2(h['vy'], h['vx']) - num.pi / 2
        cos_a, sin_a = num.cos(aci), num.sin(aci)

        yeni = [[p[0] * cos_a - p[1] * sin_a + h['x'], p[0] * sin_a + p[1] * cos_a + h['y']] for p in ucak_sekli]

        gorsel_nesneler[i]["patch"].set_xy(yeni)
        gorsel_nesneler[i]["patch"].set_facecolor(renk)
        gorsel_nesneler[i]["etiket"].set_text(f"{'DOST' if h['dost'] else 'DÜŞMAN'}\n X:{h['x']:.1f} Y:{h['y']:.1f}")
        gorsel_nesneler[i]["etiket"].xy = (h['x'], h['y'])

    # radar çizgisi
    angle = num.radians(derece)
    cizgi.set_data([0, 10 * num.cos(angle)], [0, 10 * num.sin(angle)])

    return [cizgi] + [n["patch"] for n in gorsel_nesneler]


anim = FuncAnimation(fig, guncelle, frames=range(0, 360, 2),interval = 50, blit = False)
plt.show()

#makine öğrenmesi kısmı
print("ML eğitimi başlıyor...")
X_train, X_test, y_train, y_test = train_test_split(veriler, etiketler, test_size = 0.2, random_state = 42) #eğitim

model = RandomForestClassifier(n_estimators = 100) # modelin tanımı

model.fit(X_train, y_train) #Eğitim : Bilgisayarın öğrendiği kısım

tahmin = model.predict(X_test) # tahmin

acc = accuracy_score(y_test, tahmin) # Başarı oranınını hesaplama kısmı
print("Doğruluk:", acc)

cm = confusion_matrix(y_test, tahmin)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot = True, fmt= "d" , xticklabels = ["Yok", "Var"], yticklabels = ["Yok", "Var"])
plt.title("Karışıklık Matrisi")
plt.show()


# özellik analizi ksımı
df = pd.DataFrame(veriler, columns = ["Max", "Mean", "Std"])
df["Label"] = etiketler

plt.figure(figsize=(8, 6))
sns.scatterplot(data = df, x = "Max", y = "Std", hue = "Label", alpha = 0.6)

plt.title("Özellik Analizi")
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
import scipy.fft as fft
from scipy.signal import spectrogram  #bir sinyalin frekans içeriğinin zamanla nasıl değiştiğini görselleştirmek için kullandım.
import random

# örneklem frekansı
orneklem_frekansi = 1000
zaman = np.linspace(0, 1, orneklem_frekansi)

# Uçak şekli koordinatları
ucak_sekli = [[0, 0.8],[0.2, 0.2],[0.7, -0.4],[0.2, -0.2], [0, -0.6],[-0.2, -0.2],[-0.7, -0.4],[-0.2, 0.2]] #nokta görünümü yerine uçak şeklinde olması adına kullnadım

hedefler = [] # Hedefler listesi
def hedef_olustur():
    return {
        "x": random.uniform(-8, 8),
        "y": random.uniform(-8, 8), 
        "vx": random.uniform(-0.2, 0.2), 
        "vy": random.uniform(-0.2, 0.2), 
        "dost": random.randint(0, 1), # 1 : Dost, 0 : Düşman
        "aci": random.uniform(0, 3)
    }

for _ in range(6):
    hedefler.append(hedef_olustur())

def radar_sinyali_uret():
    sinyal = np.zeros(len(zaman))

    for h in hedefler:
        mesafe = np.sqrt(h["x"] ** 2 + h["y"] ** 2)
        hiz = (h["x"] * h["vx"] + h["y"] * h["vy"]) / (mesafe + 1e-6)
        frekans = 5 + hiz * 10
        sinyal += np.sin(2 * np.pi * frekans * zaman) / (mesafe + 1)
    sinyal += np.random.normal(0, 0.4, len(zaman))
    return sinyal

# Görselleştirme ekranı
fig = plt.figure(figsize=(12, 6))
ax_radar = plt.subplot(1, 2, 1)
ax_fft = plt.subplot(2, 2, 2)
ax_spec = plt.subplot(2, 2, 4)
ax_radar.set_facecolor("black")
ax_radar.set_xlim(-10, 10)
ax_radar.set_ylim(-10, 10)

# Radar halkaları
for r in [2, 4, 6, 8, 10]:
    ax_radar.add_patch(plt.Circle((0, 0), r, fill = False, color = 'lime', alpha = 0.4))
tarama_cizgisi, = ax_radar.plot([], [], color = 'lime')

ucak_nesneleri = []
etiket_nesneleri = []
def cizimleri_baslat():
    global ucak_nesneleri, etiket_nesneleri

    for p in ucak_nesneleri:
        p.remove()
    for l in etiket_nesneleri:
        l.remove()

    ucak_nesneleri.clear()
    etiket_nesneleri.clear()

    for _ in hedefler:
        p = patches.Polygon(ucak_sekli, color = 'gray')
        ax_radar.add_patch(p)
        ucak_nesneleri.append(p)

        lbl = ax_radar.annotate ("", xy = (0, 0), xytext = (8, 8), textcoords = "offset points", fontsize = 7, color = "white", bbox = dict(boxstyle = "round", fc = "black", alpha = 0.5))
        etiket_nesneleri.append(lbl)

cizimleri_baslat()


def hedefleri_guncelle():
    for h in hedefler:
        h["x"] += h["vx"]
        h["y"] += h["vy"]
        h["aci"] += 0.03

    # Ekran dışına çıkanları temizle
    hedefler[:] = [h for h in hedefler if abs(h["x"]) < 12 and abs(h["y"]) < 12]

    # Yeni hedef oluştur
    if len(hedefler) < 8 and random.random() < 0.3:
        hedefler.append(hedef_olustur())


def guncelle(derece):
    hedefleri_guncelle()

    if len(ucak_nesneleri) != len(hedefler):
        cizimleri_baslat()

    sinyal = radar_sinyali_uret()

    # FFT ve Spektrogram hesaplamaları
    fft_verisi = np.abs(fft.fft(sinyal))

    ax_fft.clear()
    ax_fft.plot(fft_verisi, color = "cyan")
    ax_fft.set_title("FFT Spektrumu")
    
    ax_spec.clear()
    f, tt, Sxx = spectrogram(sinyal, fs = orneklem_frekansi)
    ax_spec.pcolormesh(tt, f, Sxx, shading = 'gouraud')
    ax_spec.set_title("Spektrogram")

    # radar tarama çizgisi
    aci = np.radians(derece)
    tarama_cizgisi.set_data([0, 10 * np.cos(aci)], [0, 10 * np.sin(aci)])

    for i, h in enumerate(hedefler):
        mesafe = np.sqrt(h["x"] ** 2 + h["y"] ** 2)
        doppler = (h["x"] * h["vx"] + h["y"] * h["vy"]) / (mesafe + 1e-6)

        # Renk mantığı
        if mesafe < 2.5:
            renk = "white"
        else:
            if h["dost"]:
                renk = "green" if doppler < 0 else "blue"
            else:
                renk = "red" if doppler < 0 else "hotpink"

        # uçak döndürme ve konumlandırma kodları
        aci_ucak = np.arctan2(h["vy"], h["vx"]) - np.pi / 2
        c, s = np.cos(aci_ucak), np.sin(aci_ucak)

        sekil = [[p[0] * c - p[1] * s + h["x"], p[0] * s + p[1] * c + h["y"]] for p in ucak_sekli]

        ucak_nesneleri[i].set_xy(sekil)
        ucak_nesneleri[i].set_facecolor(renk)
        etiket_nesneleri[i].xy = (h["x"], h["y"])
        etiket_nesneleri[i].set_text(f"{'DOST' if h['dost'] else 'DÜŞMAN'}\n X:{h['x']:.1f} Y:{h['y']:.1f}")

    return [tarama_cizgisi] + ucak_nesneleri + etiket_nesneleri

#çalıştırma bölümü
animasyon = FuncAnimation(fig, guncelle, frames = 360, interval = 50, blit = False)
plt.tight_layout()
plt.show()
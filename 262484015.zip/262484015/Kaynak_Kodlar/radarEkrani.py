import numpy as num  
import matplotlib.pyplot as plot  
from matplotlib.animation import FuncAnimation # Matplotlib kütüphanesinde hareketli grafikler oluşturmak için kullandım.

#1. kısım : radarın tasarımı
fig, gAlani = plot.subplots(figsize = (8, 8)) #tuval boyutu
gAlani.set_facecolor("black") #arka plan
# Radar limitleri, maksimum görüş açısını belirlemek için kullanıyorum
gAlani.set_xlim(-10, 10)
gAlani.set_ylim(-10, 10)

#radarın çemberleri
for radius in [2, 4, 6, 8, 10]: #halka yarı çapları
    cember = plot.Circle((0,0), radius, color = 'green', fill = False, alpha = 0.5) # matplotlibin çember geometrik nesnesi şablonu
    gAlani.add_artist(cember)

cizgi, = gAlani.plot([], [], color = 'lime', linewidth = 1.2) #Bu satır radar ekranının merkezden dışarıya doğru sürekli dönen o parlak tarama çizgisini oluşturduğum yer.
#ve bu satırda cizgiden sonra virgül kullanıldı listedeki ilk elemanı al demek aksi takdirde kod çalışmıyor

hedefX = 4
hedefY = 6
gAlani.plot(hedefX, hedefY, 'ro', markersize = 8) #ro(kırmızı renk ve o şeklinde nokta manasında kullanılır)


#animasyonun fonksiyonu
def guncelle(derece):
    radyan = num.radians(derece)
    x = 10 * num.cos(radyan)
    y = 10 * num.sin(radyan)
    cizgi.set_data([0, x], [0, y])
    return cizgi,

animasyon = FuncAnimation(fig, guncelle, frames = num.arange(0, 360, 2), interval = 50, blit = True)
# arange = adar Terimiyle: Radarın her adımda 2 derecelik açılarla dönüyor demektir.
# blit = animasyonun her karede tüm ekranı silip baştan çizmemesi, bilgisayarı çok yormaması için kullandım
gAlani.set_aspect('equal')# bu kod yazılmadığı takdirde tuval alanı tam ekrana alındığında oval şekildeo olacaktır
plot.show()

#2. kısım : hedef hareketi, rengi
fig, gAlani = plot.subplots(figsize=(8, 8)) 
gAlani.set_facecolor('black')
gAlani.set_xlim(-10, 10)
gAlani.set_ylim(-10, 10)

for radius in [2, 4, 6, 8, 10]:
    gAlani.add_patch(plot.Circle((0,0), radius, color = 'green', fill = False, alpha = 0.5))
    
hedefX = 4
hedefY = 6
hizX = -0.15
hizY = -0.16
cizgi, = gAlani.plot([], [], color = 'lime', linewidth = 2)
hedef_nokta, = gAlani.plot([], [], 'ro', markersize = 8)


def guncelle(derece):
    global hedefX, hedefY

    # Çizgi hareketi
    radyan = num.radians(derece)
    x, y = 10 * num.cos(radyan), 10 * num.sin(radyan)
    cizgi.set_data([0, x], [0, y])
    
    # Nokta hareketi ve Sınır Kontrolü
    hedefX += hizX
    hedefY += hizY
    
    # Sınır dışına çıkarsa sıfırla
    if abs(hedefX) > 10 or abs(hedefY) > 10:
        hedefX, hedefY = 4, 6
        
    mesafe = num.sqrt(hedefX ** 2 + hedefY ** 2) # uzaklık hesabı
    doppler_hizi = (hedefX * hizY + hedefY * hizY) / (mesafe + 0.001) #radyal hız hesaplamak (doppler)

    if mesafe < 2.5:
        hedef_nokta.set_color('white')
    #uzaklaşan hedefler
    elif doppler_hizi > 0.04:
        hedef_nokta.set_color('purple')
    elif doppler_hizi > 0.02:
        hedef_nokta.set_color('blue')
    elif doppler_hizi > 0.002:
        hedef_nokta.set_color('green')

    #yaklaşan hedefler
    elif doppler_hizi < -0.04:
        hedef_nokta.set_color('red')
    elif doppler_hizi < -0.02:
        hedef_nokta.set_color('orange')
    elif doppler_hizi < -0.002:
        hedef_nokta.set_color('yellow')
    
    for radius in [2, 4, 6, 8, 10]:
        circle = plot.Circle((0,0), radius, color = 'green', fill = False, alpha = 0.5)
        gAlani.add_artist(circle)

    hedef_nokta.set_data([hedefX], [hedefY])
    return cizgi, hedef_nokta

# çalıştırma kısmı
animasyon = FuncAnimation(fig, guncelle, frames = range(0, 360, 2), interval = 50, blit = True)
gAlani.set_aspect('equal')
plot.show()
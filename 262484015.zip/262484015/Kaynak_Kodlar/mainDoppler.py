import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0' # TensorFlow'un oneDNN uyarılarını gizler

import numpy as num
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
import scipy.fft as fft

from sklearn.model_selection import train_test_split
import tensorflow as tf # türev, matris çarpımları vb. işlemleri,  işlemci veya ekran kartı üzerinde çok hızlı bir şekilde yapmanızı sağlar.
from tensorflow.keras import Sequential #Bir yapay sinir ağı mimarisini oluşturmak için kullanılan "katman yığını" modelidir.
from tensorflow.keras.layers import Conv1D, Dense, Flatten  # Conv1D, Dense, Flatten : Bir sinir ağının "beyin" kısmını oluşturan temel bileşenlerdir

orneklemFrekansı = 1000
zaman = num.linspace(0, 1, orneklemFrekansı)

hedefler = [
    {'x': 4, 'y': 6, 'vx': -0.15, 'vy': -0.16, 'dost': False, 'acisi': 0.0},
    {'x': 0, 'y': -8, 'vx': 0.05, 'vy': 0.2, 'dost': False, 'acisi': 1.5},
    {'x': -5, 'y': 2, 'vx': 0.1, 'vy': -0.05, 'dost': True, 'acisi': 3.0},
    {'x': -2, 'y': -3, 'vx': -0.09, 'vy': 0.4, 'dost': True, 'acisi': 2.5},
]

ucak_sekli = [[0, 0.8],[0.2, 0.2],[0.7, -0.4],[0.2, -0.2], [0, -0.6],[-0.2, -0.2],[-0.7, -0.4],[-0.2, 0.2]] # nokta yerine uçak şeklini verir


class Kalman:
    def __init__(self):
        self.x = 0 # Sistemin o anki "en iyi tahmin edilen" konumu
        self.P = 1 # Tahminimizin ne kadar güvenilir olduğu, Başlangıçta belirsizlik yüksektir.
        self.Q = 0.01 # Sistemin kendi hareketindeki tahmin edilemezlik.
        self.R = 0.1 # Sensörün (radar) verilerindeki hata payı. R ne kadar büyükse, sensöre o kadar az güvenilir.

    def guncelle(self, z):
        self.P += self.Q
        K = self.P / (self.P + self.R)
        self.x = self.x + K * (z - self.x)
        self.P = (1 - K) * self.P
        return self.x

kalman_x = [Kalman() for _ in hedefler]
kalman_y = [Kalman() for _ in hedefler]

# radar sinyali (doppler)
def radar_sinyal():
    sinyal = num.zeros(len(zaman))

    for h in hedefler:
        mesafe = num.sqrt(h['x'] ** 2 + h['y'] ** 2)
        hiz = (h['x'] * h['vx'] + h['y'] * h['vy']) / (mesafe + 1e-6)
        freq = 5 + hiz * 8
        echo = num.sin(2 * num.pi * freq * zaman) / (mesafe + 1)
        sinyal += echo

    sinyal += num.random.normal(0, 0.5, len(zaman))
    return sinyal

#tuval
fig, ax = plt.subplots(figsize=(8, 8))
ax.set_xlim(-10, 10)
ax.set_ylim(-10, 10)
ax.set_facecolor("black")

#radar halkaları
for r in [2, 4, 6, 8, 10]:
    ax.add_patch(plt.Circle((0, 0), r, fill = False, color = 'lime', alpha = 0.5))

cizgi, = ax.plot([], [], color = 'lime')

patch_list = []
label_list = []
for _ in hedefler:
    p = patches.Polygon(ucak_sekli, color = 'gray')
    ax.add_patch(p)
    patch_list.append(p)

    t = ax.annotate("", xy = (0, 0), xytext = (10, 10), textcoords = "offset points", fontsize= 7 , color = "white", bbox=dict(boxstyle = "round", fc = "black", alpha = 0.6))
    label_list.append(t)

# güncelleme fonksiyonu
def guncelle(derece):
    sinyal = radar_sinyal()

    for i, h in enumerate(hedefler):
        h['acisi'] += 0.05
        h['vx'] += num.cos(h['acisi']) * 0.005
        h['vy'] += num.sin(h['acisi']) * 0.005
        h['vx'] = num.clip(h['vx'], -0.25, 0.25)
        h['vy'] = num.clip(h['vy'], -0.25, 0.25)
        h['x'] += h['vx']
        h['y'] += h['vy']

        x = kalman_x[i].guncelle(h['x'])
        y = kalman_y[i].guncelle(h['y'])

        # mesafe + doppler
        mesafe = num.sqrt(x ** 2 + y ** 2)
        doppler = (x *h['vx'] + y *h['vy']) / (mesafe + 1e-6)
       
        if h['dost']:
            renk = "green" if doppler < 0 else "blue"
        else:
            renk = "red" if doppler < 0 else "hotpink"

        if mesafe < 2.5:
            renk = "white"

        # yön hesabı bölümü
        aci = num.arctan2(h['vy'], h['vx']) - num.pi / 2
        cos_a, sin_a = num.cos(aci), num.sin(aci)

        shape = [[p[0] * cos_a - p[1] * sin_a + x, p[0] * sin_a + p[1] * cos_a + y] for p in ucak_sekli]
        patch_list[i].set_xy(shape)
        patch_list[i].set_facecolor(renk)

        durum = "DOST" if h['dost'] else "DÜŞMAN"

        label_list[i].xy = (x, y)
        label_list[i].set_text(f"{durum}\n X:{x:.1f} Y:{y:.1f}\n V:{h['vx']:.2f},{h['vy']:.2f}")
        label_list[i].set_color(renk)

    # radar sweep : bir radar sisteminin çevresindeki alanı sürekli olarak gözlemlemek için kullandığı dairesel veya sektörel tarama yöntemidir.
    angle = num.radians(derece)
    cizgi.set_data([0, 10 * num.cos(angle)], [0, 10 * num.sin(angle)])
    return [cizgi] + patch_list + label_list

#çalıştırma kısmı
anim = FuncAnimation(fig, guncelle, frames = 360, interval = 50, blit = True)
plt.show()
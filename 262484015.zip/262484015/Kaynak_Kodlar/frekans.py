import matplotlib.pyplot as plot #Matplotlib'in MATLAB gibi çalışmasını sağlayan fonksiyonlar koleksiyonudur
import numpy as num # büyük, çok boyutlu diziler ve matrisler üzerinde hızlı matematiksel ve istatistiksel işlemler yapmayı sağlamak için kullanılacak

#1. kısım : radar sinyali ürettim, gürültü ekledim, grafiği çizdim
# Zamanın ekseni
orneklemFrekansı = 1000
zaman = num.linspace(0, 1, orneklemFrekansı) #Bu "linspace" zaman eksenidir. 0 ile 1 saniye arasını 1000 küçük parçaya bölüyorsun.
sinyal = num.sin(2 * num.pi * 5 * zaman) #Bu saf sinyaldir. Yani radar anteninden gönderdiğin tertemiz dalga. Burada 5Hz bir frekans seçtim
gurultu = num.random.normal(0, 0.7, 1000) #Burası işin "gerçek hayat" kısmı. Buna AWGN (Toplanabilir Beyaz Gauss Gürültüsü) denir. Elektronik cihazların ısınması veya atmosferik etkiler nedeniyle sinyal her zaman bu şekilde bozulur.

# Radar sinyali
radarSinyali = sinyal + gurultu #Radar alıcısının yakaladığı sinyal tam olarak budur: Orijinal mesaj + Karman çorman gürültü.
    
# Grafik çizimi
plot.figure(figsize = (14, 6)) #figsize : İnç cinsinden (genişlik, yükseklik)
plot.plot(zaman, radarSinyali, color='#00F0A8') #çizgileri grafiğe döker, görünür konuma sokar

#oluşacak grafiğin anlam kazanması için kullanacağız
plot.title("Sinyal Simülasyonu")
plot.xlabel("Zaman")
plot.ylabel("Genlik")
plot.grid() # grafiğin çizgilerini görünür şekile getirir
plot.show() #grafiği görüntüle


#2. kısım : frekans analizi
import scipy.fft as fft #Hızlı Fourier Dönüşümünü projede kullanabilmek için

fftSinyali = fft.fft(radarSinyali) #sinyali frekans alanına çevirir

plot.figure(figsize = (14, 6))

plot.plot(num.abs(fftSinyali), color='#00F0A8')

plot.title("FFT Frekansı Spektrumu")
plot.xlabel("Frekans")
plot.ylabel("Büyüklük")
plot.grid()
plot.show()


#3. kısım : FFT grafiğini iyileştirmek
frekanslar = num.fft.fftfreq(orneklemFrekansı, 1 / orneklemFrekansı ) # Frekans ekseni oluşturuldu
buyukluk = num.abs(fftSinyali) / len(zaman) # FFT büyüklüğü hesaplamak için
pozitif = frekanslar >= 0 # sadece pozitif frekanslar

#grafik kısmı
plot.figure(figsize=(14, 6))
plot.plot(frekanslar[pozitif], buyukluk[pozitif], color='#00F0A8')
plot.title("FFT Frekans Spektrumu")
plot.xlabel("Frekans (Hz)")
plot.ylabel("Genlik")
plot.grid()
plot.show()

#4. kısım : sinyalden anlamlı bilgiler çıkarmak
maksimumGenlik = num.max(buyukluk)
ortalamaGenlik = num.mean(buyukluk)
standartSapma = num.std(buyukluk) #sinyalin ne kadar yayıldığını gösterir
print(f"maksimum genlik : {maksimumGenlik} , ortalama genlik : {ortalamaGenlik} , standart sapma : {standartSapma}")


#5. kısım : dataset listeleri oluşturdum
veriler = []
etiketler = []

#6. kısım : örnek üretimi kısmı ve makine öğrenmesi için veri seti oluştura kısmı
for i in range(250):
    hedefVar = num.random.randint(0, 2)
    
    #hedef var
    if hedefVar == 1:
        sinyal = num.sin(2 * num.pi * 5 * zaman)
        radarSinyali = sinyal + num.random.normal(0, 0.7, orneklemFrekansı)

    #hedef yok
    else:
        radarSinyali = num.random.normal(0, 0.7, orneklemFrekansı)

   
    fftSinyali = fft.fft(radarSinyali)
    buyukluk = num.abs(fftSinyali)
    maksimumGenlik = num.max(buyukluk)
    ortalamaGenlik = num.mean(buyukluk)
    standartSapma = num.std(buyukluk)

    ozellikler = [maksimumGenlik, ortalamaGenlik, standartSapma]

    veriler.append(ozellikler)
    etiketler.append(hedefVar)

#print(veriler[:5], etiketler[:5]) # çıktıyı daha iyi anlamak için ilk 5 değer görüntülenir
print(veriler, etiketler)

#7. kısım : makine öğrenmesi için veriyi hazırlama
from sklearn.model_selection import train_test_split #veri setinmi eğitim ve test olmak üzere iki parçaya bölmek adına kullanıyorum.
from sklearn.ensemble import RandomForestClassifier  #tek bir ağaç yerine yüzlerce ağaç oluşturmak ve her ağacın tahminini oylayarak en doğru sonucu bulmaya çalışmak için kullandım
from sklearn.metrics import accuracy_score, confusion_matrix #modelin ne kadar başarılı olduğunu anlamayı sağlayan değerlendirme araçları.

#Verileri eğitim ve test olarak ayırıyoruz (%80 eğitim, %20 test)
X_egitim, X_test, y_egitim, y_test = train_test_split(veriler, etiketler, test_size = 0.3, random_state = 42) 
print(f"Eğitim veri sayısı: {len(X_egitim)}")
print(f"Test veri sayısı: {len(X_test)}")


model = RandomForestClassifier(n_estimators = 100) # modelin tanımı

model.fit(X_egitim, y_egitim)  #Eğitim : Bilgisayarın öğrendiği kısım

print("Model eğitimi tamamlandı!")

tahminler = model.predict(X_test) #Tahmin yapmak

basari = accuracy_score(y_test, tahminler) #Başarı oranınını hesaplama kısmı

print(f"Modelin Doğruluk Oranı : %{basari * 100}")


#8. kısım : verileri görselleştirme kısmı
import seaborn as sb #Matplotlib tabanlı, çok daha şık ve gelişmiş istatistiksel grafikler çizmemize yarayan kütüphanedir.
from sklearn.metrics import confusion_matrix #modelin ne kadar başarılı olduğunu anlamayı sağlayan değerlendirme aracıdır
import pandas as pd # Verileri satır-sütun (Excel tablosu gibi) yapısına sokarak görselleştirmeyi kolaylaştırır.

#Karmaşıklık Matrisi (Confusion Matrix) Görselleştirme
cm = confusion_matrix(y_test, tahminler) #Bu satır, gerçek cevaplar (y_test) ile modelin tahminlerini (tahminler) karşılaştırır.

plot.figure(figsize=(14, 6))
# Sol tarafa Karmaşıklık Matrisi
plot.subplot(1, 2, 1) #Tuvali 1 satır, 2 sütuna böl ve 1. (sol) bölgeye odaklan.
sb.heatmap(cm, annot = True, fmt = 'd', cmap = 'Blues', xticklabels = ['Hedef Yok', 'Hedef Var'], yticklabels  = ['Hedef Yok', 'Hedef Var']) #heatmap:Matrisi bir "ısı haritası" olarak çizer.
plot.title("Karmaşıklık Matrisi")
plot.xlabel("Modelin Tahmini")
plot.ylabel("Gerçek Durum")

# Özelliklerin Dağılımı (Scatter Plot)
# Verileri daha rahat görselleştirmek için bir DataFrame oluşturalım
df = pd.DataFrame(veriler, columns = ["Maks Genlik", "Ortalama Genlik", "Std Sapma"])
df['Etiket'] = etiketler

# Sağ tarafa Özellik Dağılımı
plot.subplot(1, 2, 2)
sb.scatterplot(data = df, x = "Maks Genlik", y = "Std Sapma", hue = "Etiket", alpha = 0.6, palette = "viridis")
plot.title("Özelliklerin Uzaydaki Dağılımı")
plot.xlabel("Maksimum Genlik")
plot.ylabel("Standart Sapma")

plot.tight_layout() #Grafiklerin ve yazıların birbirine girmesini engeller, aradaki boşlukları otomatik ayarlar.
plot.show()

